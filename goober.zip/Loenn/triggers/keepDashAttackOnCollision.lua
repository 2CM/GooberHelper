local trigger = {}

trigger.name = "GooberHelper/KeepDashAttackOnCollision"
trigger.placements = {
    name = "Keep DashAttack On Collision",
    data = {
        keepDashAttackOnCollision = true
    }
}


return trigger