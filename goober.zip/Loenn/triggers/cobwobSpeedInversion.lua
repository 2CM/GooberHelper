local trigger = {}

trigger.name = "GooberHelper/CobwobSpeedInversion"
trigger.placements = {
    name = "Cobwob Speed Inversion",
    data = {
        cobwobSpeedInversion = true,
        allowRetentionReverse = true
    }
}


return trigger