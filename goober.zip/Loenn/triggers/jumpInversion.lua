local trigger = {}

trigger.name = "GooberHelper/JumpInversion"
trigger.placements = {
    name = "Jump Inversion",
    data = {
        jumpInversion = true,
        allowClimbJumpInversion = true
    }
}


return trigger