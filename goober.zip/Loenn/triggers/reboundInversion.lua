local trigger = {}

trigger.name = "GooberHelper/ReboundInversion"
trigger.placements = {
    name = "ReboundInversion",
    data = {
        reboundInversion = true
    }
}


return trigger